<?php 
    header('Location: /');
    exit();
?>